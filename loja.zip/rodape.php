<?php
/**
 * Created by PhpStorm.
 * User: Robson
 * Date: 24/10/2016
 * Time: 11:39
 */
?>

            </div>

        </div>
<script src="js/loja.js" type="text/javascript"></script>
    </body>
</html>