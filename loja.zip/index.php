<?php
/**
 * Created by PhpStorm.
 * User: Robson
 * Date: 24/10/2016
 * Time: 10:57
 */
?>

<?php include("cabecalho.php"); ?>

    <?php $nome = "Michael"; ?>
    <h1>Bem vindo <?php echo $nome; ?></h1>

<?php include("rodape.php"); ?>