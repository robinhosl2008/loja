<?php
/**
 * Created by PhpStorm.
 * User: Robson
 * Date: 25/10/2016
 * Time: 11:58
 */

include('banco-produto.php');

$id = $_POST['id'];

$result = removeProduto($id);

if($result == true){
    header('location: produto-lista?acao=true');
}else{ $msg_error = mysqli_error($conexao);
    header('location: produto-lista?acao=false');
}