/**
 * Created by Robson on 25/10/2016.
 */

if($('.alert').is(':visible')){
    $('.alert').fadeOut(3000);
}